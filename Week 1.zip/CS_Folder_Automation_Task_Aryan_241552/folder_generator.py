"""
folder_generator.py
Author: Muhammad Aryan Tariq (Roll No. 241552, Section F24-B)
Week 1 Task - Course Folder Automation System

Given a course code and a destination directory, this module builds and
physically creates a standard subfolder structure for a course:
Assignments, Quizzes, Midterm, Final, Lab, Project, Presentations.
"""

import re
import argparse
from pathlib import Path
from typing import Tuple, List

SUBFOLDERS = [
    "Assignments",
    "Quizzes",
    "Midterm",
    "Final",
    "Lab",
    "Project",
    "Presentations",
]

# Characters disallowed across Windows/macOS/Linux filesystems
INVALID_CHARS_PATTERN = re.compile(r'[<>:"/\\|?*\x00-\x1F]')

# Reserved device names on Windows - must be blocked even without special chars
WINDOWS_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


class InvalidCourseCodeError(Exception):
    """Raised when a course code is empty, malformed, or unsafe for use as a folder name."""
    pass


class DestinationNotFoundError(Exception):
    """Raised when the destination path is missing, invalid, or not a directory."""
    pass


class CourseFolderExistsError(Exception):
    """Raised when a course folder already exists and skip_if_exists was not requested."""
    pass


def validate_course_code(course_code: str) -> str:
    """Validate and normalize a course code, raising InvalidCourseCodeError if unsafe."""
    if not course_code or not course_code.strip():
        raise InvalidCourseCodeError("Course code cannot be empty.")

    cleaned = course_code.strip()

    if INVALID_CHARS_PATTERN.search(cleaned):
        raise InvalidCourseCodeError(
            f"Course code '{course_code}' contains invalid characters "
            f'(< > : " / \\ | ? *).'
        )

    # Trailing dots/spaces are silently stripped by Windows and can cause
    # mismatches between the intended and actual folder name.
    if cleaned != cleaned.rstrip(". "):
        raise InvalidCourseCodeError(
            f"Course code '{course_code}' cannot end with a space or a period."
        )

    if cleaned.upper() in WINDOWS_RESERVED_NAMES:
        raise InvalidCourseCodeError(
            f"Course code '{course_code}' is a reserved system name on Windows."
        )

    return cleaned


def validate_destination(destination: str, create_if_missing: bool = True) -> Path:
    """Resolve the destination path, optionally creating it if missing."""
    dest_path = Path(destination).expanduser().resolve()

    if not dest_path.exists():
        if create_if_missing:
            try:
                dest_path.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                raise DestinationNotFoundError(
                    f"Destination '{destination}' does not exist and could not be created: {e}"
                )
        else:
            raise DestinationNotFoundError(
                f"Destination path '{destination}' does not exist."
            )

    if not dest_path.is_dir():
        raise DestinationNotFoundError(
            f"Destination path '{destination}' exists but is not a directory."
        )

    return dest_path


def build_folder_list(clean_course_code: str, resolved_destination: Path) -> Tuple[Path, List[Path]]:
    """Build the course root path and its list of subfolder paths.

    Expects an already-validated course code and an already-resolved
    destination Path, so validation is not repeated here.
    """
    course_root = resolved_destination / clean_course_code
    subfolder_paths = [course_root / sub for sub in SUBFOLDERS]
    return course_root, subfolder_paths


def create_course_folders(
    course_code: str,
    destination: str,
    skip_if_exists: bool = False,
) -> dict:
    """Create the full course folder tree.

    Args:
        course_code: e.g. "CS301".
        destination: parent directory in which the course folder will live.
        skip_if_exists: if True, an already-existing course folder is left
            as-is (missing subfolders are still filled in) instead of
            raising CourseFolderExistsError. No existing files are ever
            deleted or overwritten by this function.
    """
    clean_code = validate_course_code(course_code)
    dest_path = validate_destination(destination, create_if_missing=True)
    course_root, subfolder_paths = build_folder_list(clean_code, dest_path)

    if course_root.exists() and not skip_if_exists:
        raise CourseFolderExistsError(
            f"A folder for course '{clean_code}' already exists at '{course_root}'."
        )

    already_existed = course_root.exists()

    course_root.mkdir(parents=True, exist_ok=True)
    for sub in subfolder_paths:
        sub.mkdir(parents=True, exist_ok=True)

    return {
        "course_code": clean_code,
        "course_root": str(course_root),
        "subfolders": [str(p) for p in subfolder_paths],
        "status": "verified_existing" if already_existed else "created",
    }


def _main():
    parser = argparse.ArgumentParser(
        description="Create a standard subfolder tree for a course."
    )
    parser.add_argument("course_code", help="e.g. CS301")
    parser.add_argument("destination", help="Parent directory for the course folder")
    parser.add_argument(
        "--skip-if-exists",
        action="store_true",
        help="Don't error if the course folder already exists",
    )
    args = parser.parse_args()

    result = create_course_folders(
        args.course_code, args.destination, skip_if_exists=args.skip_if_exists
    )
    print(result)


if __name__ == "__main__":
    _main()
