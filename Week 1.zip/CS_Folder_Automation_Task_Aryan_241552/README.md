# Course Folder Automation System — Week 1 Task

**Author:** Muhammad Aryan Tariq
**Roll No:** 241552
**Section:** F24-B

## What it does

Given a course code (e.g. `CS301`) and a destination directory, `folder_generator.py`
creates the following standard subfolder structure:

```
<destination>/<COURSE_CODE>/
├── Assignments
├── Quizzes
├── Midterm
├── Final
├── Lab
├── Project
└── Presentations
```

## Files

| File | Purpose |
|---|---|
| `folder_generator.py` | Core module — validation, folder-tree building, and folder creation |
| `test_folder_creation.py` | Automated test script — 6 scenarios / 10 checks |
| `test_run_log.txt` | Captured output of the final passing test run |
| `241552.docx` | Full task report with stepwise terminal screenshots and explanations |
| `screenshots/` | Raw terminal screenshots referenced in the report |

## How to run

```bash
# Run the test suite
python3 test_folder_creation.py

# Use the CLI directly
python3 folder_generator.py CS301 ./output
python3 folder_generator.py CS301 ./output --skip-if-exists
```

## Edge cases handled

1. **Destination doesn't exist** → auto-created with `mkdir(parents=True)`.
2. **Course folder already exists** → raises `CourseFolderExistsError` unless
   `skip_if_exists=True` is passed.
3. **Invalid characters in course code** → raises `InvalidCourseCodeError`
   before anything touches the disk. This also covers:
   - Empty / whitespace-only codes
   - Trailing dots or spaces (stripped silently on Windows)
   - Windows-reserved device names (`CON`, `PRN`, `COM1`, etc.)

## Testing done

Tested against 4 sample course codes (`CS301`, `SE-205`, `MATH_101`, `CYB404`)
plus all 3 required edge cases — **10/10 checks passed** on the final run
(see `test_run_log.txt`).
