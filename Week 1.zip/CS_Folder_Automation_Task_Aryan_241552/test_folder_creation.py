"""
test_folder_creation.py
Author: Muhammad Aryan Tariq (Roll No. 241552, Section F24-B)

Manual test script covering 4 sample course codes plus all 3 required
edge cases (6 scenarios / 9 checks total).
Run: python3 test_folder_creation.py
"""

import shutil
from pathlib import Path
from folder_generator import (
    create_course_folders,
    InvalidCourseCodeError,
    DestinationNotFoundError,
    CourseFolderExistsError,
    SUBFOLDERS,
)

TEST_ROOT = Path("./test_output").resolve()


def reset():
    if TEST_ROOT.exists():
        shutil.rmtree(TEST_ROOT)


def check_tree(course_root: Path):
    """Verify the course root and all 7 subfolders actually exist on disk."""
    assert course_root.is_dir(), f"Missing course root: {course_root}"
    for sub in SUBFOLDERS:
        assert (course_root / sub).is_dir(), f"Missing subfolder: {sub}"
    print(f"    verified {len(SUBFOLDERS)}/7 subfolders on disk")


def run():
    reset()
    passed, failed = 0, 0

    print("=" * 60)
    print("TEST 1: Normal course code, destination does not exist yet")
    print("=" * 60)
    try:
        r = create_course_folders("CS301", str(TEST_ROOT / "new_dest"))
        check_tree(Path(r["course_root"]))
        print("PASS -", r["status"])
        passed += 1
    except Exception as e:
        print("FAIL -", e)
        failed += 1

    print("\n" + "=" * 60)
    print("TEST 2: Sample code SE-205, existing destination")
    print("=" * 60)
    try:
        r = create_course_folders("SE-205", str(TEST_ROOT / "new_dest"))
        check_tree(Path(r["course_root"]))
        print("PASS -", r["status"])
        passed += 1
    except Exception as e:
        print("FAIL -", e)
        failed += 1

    print("\n" + "=" * 60)
    print("TEST 3: Sample code MATH_101, nested destination auto-created")
    print("=" * 60)
    try:
        r = create_course_folders("MATH_101", str(TEST_ROOT / "new_dest"))
        check_tree(Path(r["course_root"]))
        print("PASS -", r["status"])
        passed += 1
    except Exception as e:
        print("FAIL -", e)
        failed += 1

    print("\n" + "=" * 60)
    print("TEST 3b: Sample code CYB404")
    print("=" * 60)
    try:
        r = create_course_folders("CYB404", str(TEST_ROOT / "new_dest"))
        check_tree(Path(r["course_root"]))
        print("PASS -", r["status"])
        passed += 1
    except Exception as e:
        print("FAIL -", e)
        failed += 1

    print("\n" + "=" * 60)
    print("TEST 4 (edge case): Duplicate folder -> should raise CourseFolderExistsError")
    print("=" * 60)
    try:
        create_course_folders("CS301", str(TEST_ROOT / "new_dest"))
        print("FAIL - no exception raised")
        failed += 1
    except CourseFolderExistsError as e:
        print("PASS - correctly raised:", e)
        passed += 1

    print("\n" + "=" * 60)
    print("TEST 5 (edge case): Invalid characters in course code -> InvalidCourseCodeError")
    print("=" * 60)
    for bad_code in ["CS/301", "CS:301", "CON", "  "]:
        try:
            create_course_folders(bad_code, str(TEST_ROOT / "new_dest"))
            print(f"FAIL - '{bad_code}' should have been rejected")
            failed += 1
        except InvalidCourseCodeError as e:
            print(f"PASS - '{bad_code}' correctly rejected: {e}")
            passed += 1

    print("\n" + "=" * 60)
    print("TEST 6 (edge case): skip_if_exists=True on existing folder -> no error")
    print("=" * 60)
    try:
        r = create_course_folders("CS301", str(TEST_ROOT / "new_dest"), skip_if_exists=True)
        check_tree(Path(r["course_root"]))
        print("PASS -", r["status"])
        passed += 1
    except Exception as e:
        print("FAIL -", e)
        failed += 1

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)


if __name__ == "__main__":
    run()
