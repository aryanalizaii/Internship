"""
record_manager.py
Author: Muhammad Aryan Tariq (Roll No. 241552, Section F24-B)
Week 2 Task - Course Folder Automation System

Purpose:
    Operates on individual PDF records inside an already-created course
    folder tree (built by folder_generator.py in Week 1). Handles adding,
    renaming, moving, and deleting record files, with filename-collision
    handling and clear extension points for Abdullah's database layer
    and the Week 3 security module.

Integration contract (for Abdullah / Amna):
    Every function that changes the state of a record accepts an optional
    callback:
        add_record(...,   db_insert_callback=...)
        rename_record(..., db_update_callback=...)
        move_record(...,   db_update_callback=...)
        delete_record(..., db_delete_callback=...)

    The callback receives a dict describing what happened and is called
    ONLY after the disk operation succeeds. This is intentional: disk
    state is the source of truth, and the DB is updated to reflect it -
    never the other way around. If the callback raises, the caller
    (Ayesha's GUI layer / Abdullah's service layer) is responsible for
    deciding whether to roll back the disk change.

Security hook insertion points (Week 3):
    Marked inline with "SECURITY HOOK INSERTION POINT". These are the
    exact spots identified for Amna's Week 2 review task, where Week 3
    will plug in file hashing (e.g. SHA-256) and audit logging without
    touching the surrounding logic.
"""

import shutil
from pathlib import Path
from typing import Callable, Optional

# ---------------------------------------------------------------------------
# Constants (must mirror SUBFOLDERS in folder_generator.py from Week 1)
# ---------------------------------------------------------------------------

CATEGORIES = [
    "Assignments",
    "Quizzes",
    "Midterm",
    "Final",
    "Lab",
    "Project",
    "Presentations",
]

ALLOWED_EXTENSION = ".pdf"


# ---------------------------------------------------------------------------
# Custom Exceptions
# ---------------------------------------------------------------------------

class InvalidCategoryError(Exception):
    """Raised when a category is not one of the fixed 7 course categories."""
    pass


class InvalidFileTypeError(Exception):
    """Raised when the source file is not a PDF."""
    pass


class RecordNotFoundError(Exception):
    """Raised when a target file or category folder does not exist on disk."""
    pass


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_category(category: str) -> str:
    """Ensures the category is one of the 7 fixed course subfolders."""
    if category not in CATEGORIES:
        raise InvalidCategoryError(
            f"'{category}' is not a valid category. Must be one of: {CATEGORIES}"
        )
    return category


def validate_pdf(file_path: Path) -> Path:
    """Ensures the source file exists and has a .pdf extension."""
    file_path = Path(file_path)

    if not file_path.exists():
        raise RecordNotFoundError(f"Source file not found: '{file_path}'")

    if file_path.suffix.lower() != ALLOWED_EXTENSION:
        raise InvalidFileTypeError(
            f"'{file_path.name}' is not a PDF. Only {ALLOWED_EXTENSION} files are allowed."
        )

    return file_path


def resolve_filename_collision(destination_folder: Path, filename: str) -> Path:
    """
    If `filename` already exists inside `destination_folder`, appends a
    counter before the extension until a free name is found.

    Example:
        notes.pdf -> notes(1).pdf -> notes(2).pdf ...

    This is the Week 2 placeholder behaviour requested in the task list
    ("no duplicate detection yet - just append a counter"). Real content-
    based duplicate detection (hashing) is a Week 3 concern.
    """
    destination_folder = Path(destination_folder)
    stem = Path(filename).stem
    suffix = Path(filename).suffix

    candidate = destination_folder / filename
    counter = 1
    while candidate.exists():
        candidate = destination_folder / f"{stem}({counter}){suffix}"
        counter += 1

    return candidate


# ---------------------------------------------------------------------------
# Step 1: Add record (copy PDF into correct category folder)
# ---------------------------------------------------------------------------

def add_record(
    source_file: str,
    course_root: str,
    category: str,
    db_insert_callback: Optional[Callable[[dict], None]] = None,
) -> dict:
    """
    Copies a PDF into the correct category subfolder under a course root.

    Args:
        source_file: path to the PDF selected/dropped by the user
        course_root: the course folder created in Week 1 (e.g. .../CS301)
        category:    one of CATEGORIES
        db_insert_callback: optional callable invoked with the record info
                             after the file is successfully copied to disk

    Returns:
        dict with keys: filename, category, course_root, file_path, status

    Raises:
        InvalidCategoryError, InvalidFileTypeError, RecordNotFoundError
    """
    validate_category(category)
    source_path = validate_pdf(source_file)

    course_root = Path(course_root)
    dest_folder = course_root / category

    if not dest_folder.exists():
        raise RecordNotFoundError(
            f"Category folder '{category}' does not exist under '{course_root}'. "
            f"Was the course folder created via folder_generator.py?"
        )

    dest_path = resolve_filename_collision(dest_folder, source_path.name)

    # shutil.copy2 preserves metadata (timestamps) - the source file the
    # user picked stays untouched on their machine.
    shutil.copy2(source_path, dest_path)

    record_info = {
        "filename": dest_path.name,
        "category": category,
        "course_root": str(course_root),
        "file_path": str(dest_path),
        "status": "added",
    }

    # ---- SECURITY HOOK INSERTION POINT #1 -------------------------------
    # Week 3 will compute a file_hash (e.g. SHA-256) here and attach it to
    # record_info BEFORE the DB insert, so Abdullah's Logs table can store
    # an integrity fingerprint at the moment of creation.
    # -----------------------------------------------------------------------

    if db_insert_callback:
        db_insert_callback(record_info)

    return record_info


# ---------------------------------------------------------------------------
# Step 2: Rename record
# ---------------------------------------------------------------------------

def rename_record(
    file_path: str,
    new_name: str,
    db_update_callback: Optional[Callable[[dict], None]] = None,
) -> dict:
    """
    Renames a record file on disk. Automatically ensures a .pdf extension
    and resolves collisions if the new name already exists in the folder.

    Args:
        file_path: full current path to the record file
        new_name:  desired new filename (with or without .pdf extension)
        db_update_callback: optional callable invoked after rename succeeds

    Returns:
        dict with keys: old_path, new_path, status

    Raises:
        RecordNotFoundError
    """
    file_path = Path(file_path)

    if not file_path.exists():
        raise RecordNotFoundError(f"Record not found: '{file_path}'")

    if not new_name.lower().endswith(ALLOWED_EXTENSION):
        new_name = f"{new_name}{ALLOWED_EXTENSION}"

    parent_folder = file_path.parent

    # Don't treat "renaming to the same name" as a collision against itself.
    if new_name == file_path.name:
        dest_path = file_path
    else:
        dest_path = resolve_filename_collision(parent_folder, new_name)
        file_path.rename(dest_path)

    result = {
        "old_path": str(file_path),
        "new_path": str(dest_path),
        "status": "renamed",
    }

    # ---- SECURITY HOOK INSERTION POINT #2 -------------------------------
    # Week 3 will log this rename action (old name, new name, timestamp,
    # user) to the audit trail here, before/alongside the DB update.
    # -----------------------------------------------------------------------

    if db_update_callback:
        db_update_callback(result)

    return result


# ---------------------------------------------------------------------------
# Step 3: Move record between category folders
# ---------------------------------------------------------------------------

def move_record(
    file_path: str,
    new_category: str,
    db_update_callback: Optional[Callable[[dict], None]] = None,
) -> dict:
    """
    Moves a record file from its current category folder into a different
    one within the SAME course (e.g. Assignments -> Midterm).

    Args:
        file_path:    full current path to the record file
        new_category: one of CATEGORIES
        db_update_callback: optional callable invoked after move succeeds

    Returns:
        dict with keys: old_path, new_path, new_category, status

    Raises:
        InvalidCategoryError, RecordNotFoundError
    """
    file_path = Path(file_path)
    validate_category(new_category)

    if not file_path.exists():
        raise RecordNotFoundError(f"Record not found: '{file_path}'")

    # Folder layout is: course_root/category/filename.pdf
    # so course_root is two levels up from the file.
    course_root = file_path.parent.parent
    dest_folder = course_root / new_category

    if not dest_folder.exists():
        raise RecordNotFoundError(
            f"Target category folder '{new_category}' does not exist under '{course_root}'."
        )

    dest_path = resolve_filename_collision(dest_folder, file_path.name)
    shutil.move(str(file_path), str(dest_path))

    result = {
        "old_path": str(file_path),
        "new_path": str(dest_path),
        "new_category": new_category,
        "status": "moved",
    }

    # ---- SECURITY HOOK INSERTION POINT #3 -------------------------------
    # Week 3 will re-verify the file_hash here after the move, to confirm
    # the file wasn't corrupted or tampered with in transit.
    # -----------------------------------------------------------------------

    if db_update_callback:
        db_update_callback(result)

    return result


# ---------------------------------------------------------------------------
# Step 4: Delete record
# ---------------------------------------------------------------------------

def delete_record(
    file_path: str,
    db_delete_callback: Optional[Callable[[str], None]] = None,
) -> dict:
    """
    Deletes a record file from disk.

    Args:
        file_path: full path to the record file to delete
        db_delete_callback: optional callable invoked with the deleted
                             file's path after disk deletion succeeds

    Returns:
        dict with keys: file_path, status

    Raises:
        RecordNotFoundError
    """
    file_path = Path(file_path)

    if not file_path.exists():
        raise RecordNotFoundError(f"Record not found: '{file_path}'")

    file_path.unlink()

    result = {
        "file_path": str(file_path),
        "status": "deleted",
    }

    # ---- SECURITY HOOK INSERTION POINT #4 -------------------------------
    # Week 3 will write a deletion audit entry here (who deleted what,
    # when) before Abdullah's function removes the corresponding DB row.
    # -----------------------------------------------------------------------

    if db_delete_callback:
        db_delete_callback(str(file_path))

    return result
