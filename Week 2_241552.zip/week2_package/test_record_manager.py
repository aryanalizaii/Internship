"""
test_record_manager.py
Author: Muhammad Aryan Tariq (Roll No. 241552, Section F24-B)
Week 2 Task: Manual test suite for add / rename / move / delete record logic,
including filename-collision handling and invalid-file-type rejection.

Run:
    python3 test_record_manager.py
"""

import shutil
from pathlib import Path

from record_manager import (
    add_record,
    rename_record,
    move_record,
    delete_record,
    InvalidCategoryError,
    InvalidFileTypeError,
    RecordNotFoundError,
    CATEGORIES,
)

TEST_BASE = Path("./test_output")
COURSE_ROOT = TEST_BASE / "CS301"
UPLOADS = TEST_BASE / "sample_uploads"


# ---------------------------------------------------------------------------
# Test scaffolding (stands in for Week 1's folder_generator + a real upload)
# ---------------------------------------------------------------------------

def setup_course_structure():
    """Mimics what folder_generator.create_course_folders() would produce."""
    for category in CATEGORIES:
        (COURSE_ROOT / category).mkdir(parents=True, exist_ok=True)


def make_sample_pdf(name: str, folder: Path = UPLOADS) -> Path:
    """Creates a dummy PDF file to use as a test source file."""
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    path.write_bytes(b"%PDF-1.4 sample content for testing\n")
    return path


def make_sample_txt(name: str, folder: Path = UPLOADS) -> Path:
    """Creates a dummy non-PDF file to test invalid-file-type rejection."""
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    path.write_text("not a pdf")
    return path


def cleanup():
    if TEST_BASE.exists():
        shutil.rmtree(TEST_BASE)


def mock_db_callback(action_name: str):
    """Stands in for Abdullah's DB insert/update/delete functions."""
    def _callback(data):
        print(f"    -> [DB CALLBACK: {action_name}] would sync: {data}")
    return _callback


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

def run_tests():
    cleanup()
    setup_course_structure()

    print("=" * 65)
    print("WEEK 2 - RECORD MANAGEMENT TEST SUITE (Aryan)")
    print("=" * 65)

    # --- Test 1: Add a valid PDF record ---------------------------------
    try:
        pdf1 = make_sample_pdf("lecture_notes.pdf")
        result = add_record(
            str(pdf1), str(COURSE_ROOT), "Assignments",
            db_insert_callback=mock_db_callback("INSERT"),
        )
        ok = Path(result["file_path"]).exists()
        print(f"[PASS] Add record -> {result['file_path']} | exists on disk: {ok}")
    except Exception as e:
        print(f"[FAIL] Add valid PDF: {e}")

    # --- Test 2: Filename collision (drop the same filename again) -----
    try:
        pdf2 = make_sample_pdf("lecture_notes.pdf", folder=UPLOADS / "resubmit")
        result = add_record(
            str(pdf2), str(COURSE_ROOT), "Assignments",
            db_insert_callback=mock_db_callback("INSERT"),
        )
        collision_handled = result["filename"] == "lecture_notes(1).pdf"
        print(f"[PASS] Duplicate filename auto-renamed -> {result['filename']} "
              f"| correct counter applied: {collision_handled}")
    except Exception as e:
        print(f"[FAIL] Collision handling: {e}")

    # --- Test 3: Reject a non-PDF file ----------------------------------
    try:
        bad_file = make_sample_txt("notes.txt")
        add_record(str(bad_file), str(COURSE_ROOT), "Assignments")
        print("[FAIL] Non-PDF file was NOT rejected")
    except InvalidFileTypeError as e:
        print(f"[PASS] Non-PDF file correctly rejected -> {e}")

    # --- Test 4: Reject an invalid category -----------------------------
    try:
        pdf3 = make_sample_pdf("quiz1.pdf")
        add_record(str(pdf3), str(COURSE_ROOT), "Homework")  # not a real category
        print("[FAIL] Invalid category was NOT rejected")
    except InvalidCategoryError as e:
        print(f"[PASS] Invalid category correctly rejected -> {e}")

    # --- Test 5: Rename a record ------------------------------------------
    try:
        target = COURSE_ROOT / "Assignments" / "lecture_notes.pdf"
        result = rename_record(
            str(target), "week1_lecture_notes",
            db_update_callback=mock_db_callback("UPDATE-RENAME"),
        )
        ok = Path(result["new_path"]).exists() and not target.exists()
        print(f"[PASS] Rename record -> {result['new_path']} | old path gone: {ok}")
    except Exception as e:
        print(f"[FAIL] Rename record: {e}")

    # --- Test 6: Move a record between categories -----------------------
    try:
        target = COURSE_ROOT / "Assignments" / "week1_lecture_notes.pdf"
        result = move_record(
            str(target), "Midterm",
            db_update_callback=mock_db_callback("UPDATE-MOVE"),
        )
        ok = Path(result["new_path"]).exists() and not target.exists()
        print(f"[PASS] Move record -> {result['new_path']} | moved correctly: {ok}")
    except Exception as e:
        print(f"[FAIL] Move record: {e}")

    # --- Test 7: Delete a record -----------------------------------------
    try:
        target = COURSE_ROOT / "Midterm" / "week1_lecture_notes.pdf"
        result = delete_record(
            str(target),
            db_delete_callback=mock_db_callback("DELETE"),
        )
        ok = not Path(result["file_path"]).exists()
        print(f"[PASS] Delete record -> {result['file_path']} | removed from disk: {ok}")
    except Exception as e:
        print(f"[FAIL] Delete record: {e}")

    # --- Test 8: Rename / move / delete on a non-existent file ----------
    ghost = COURSE_ROOT / "Assignments" / "does_not_exist.pdf"

    try:
        rename_record(str(ghost), "new_name.pdf")
        print("[FAIL] Rename on missing file did NOT raise an error")
    except RecordNotFoundError as e:
        print(f"[PASS] Rename on missing file correctly rejected -> {e}")

    try:
        move_record(str(ghost), "Final")
        print("[FAIL] Move on missing file did NOT raise an error")
    except RecordNotFoundError as e:
        print(f"[PASS] Move on missing file correctly rejected -> {e}")

    try:
        delete_record(str(ghost))
        print("[FAIL] Delete on missing file did NOT raise an error")
    except RecordNotFoundError as e:
        print(f"[PASS] Delete on missing file correctly rejected -> {e}")

    print("=" * 65)
    print("Test run complete. Inspect ./test_output/CS301/ to see final state.")
    print("=" * 65)


if __name__ == "__main__":
    run_tests()
