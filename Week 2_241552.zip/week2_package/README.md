# Week 2 Submission — Aryan (Record Management Module)

**Project:** Course Folder Automation System
**Student:** Muhammad Aryan Tariq — Roll No. 241552 — Section F24-B
**Scope:** Add Records & Full Record Management (individual contribution only)

## Contents of this package

| File | Description |
|---|---|
| `record_manager.py` | Core logic — add / rename / move / delete PDF records, with filename-collision handling and custom exceptions |
| `test_record_manager.py` | Automated test suite covering 10 functional and edge-case scenarios |
| `test_results.txt` | Full terminal output of the test run, showing 10/10 PASS |
| `Week2_Report_Aryan_241552.docx` | Professional Word report — design, implementation, testing, and integration notes |
| `README.md` | This file |

## How to run

```bash
python3 test_record_manager.py
```

Requires only the Python 3 standard library — no external dependencies.

## What this module does

Given a course folder already created by Week 1's `folder_generator.py`, this module handles individual PDF records within it:

- **`add_record()`** — copies a selected PDF into the correct category subfolder (Assignments, Quizzes, Midterm, Final, Lab, Project, Presentations)
- **`rename_record()`** — renames a file on disk
- **`move_record()`** — relocates a file between category folders (e.g. Assignments → Midterm)
- **`delete_record()`** — removes a file from disk

Every function accepts an optional callback (`db_insert_callback`, `db_update_callback`, `db_delete_callback`) as its designated integration point for the database layer — the disk operation always completes first, and the callback fires only on success.

## Edge cases handled

- Duplicate filenames → automatically resolved with a numeric counter (`notes.pdf` → `notes(1).pdf`)
- Non-PDF files → rejected via `InvalidFileTypeError`
- Invalid categories → rejected via `InvalidCategoryError`
- Operations on missing files → rejected via `RecordNotFoundError`

## Integration points for the team

- **Ayesha (GUI):** wire the right-click context menu (Open, Rename, Delete, Move) to `rename_record()`, `delete_record()`, `move_record()`
- **Abdullah (Database):** plug Records-table insert/update/delete functions into the three callback parameters
- **Amna (Review/Security):** four `SECURITY HOOK INSERTION POINT` comments in `record_manager.py` mark where Week 3's hashing/audit-logging will attach

See the Word report for full design rationale, code walkthrough, and the complete testing screenshot trail.
